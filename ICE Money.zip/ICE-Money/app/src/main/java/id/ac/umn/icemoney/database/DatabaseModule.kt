package id.ac.umn.icemoney.database

class DatabaseModule {
}
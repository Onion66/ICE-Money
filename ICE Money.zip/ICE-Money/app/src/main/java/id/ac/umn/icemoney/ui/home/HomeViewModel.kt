package id.ac.umn.icemoney.ui.home

import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() { }
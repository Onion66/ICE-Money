package id.ac.umn.icemoney.repository

object UserRepository { }